package com.example.myapplication;

import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText inputSalario;
    RadioGroup groupAumento;
    Button btnCalcular;
    TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_application);

        inputSalario = findViewById(R.id.inputSalario);
        groupAumento = findViewById(R.id.groupAumento);
        btnCalcular = findViewById(R.id.btnCalcular);
        textResultado = findViewById(R.id.textResultado);

        btnCalcular.setOnClickListener(v -> {
            String salarioStr = inputSalario.getText().toString();

            if (salarioStr.isEmpty()) {
                Toast.makeText(this, "Digite o salário atual!", Toast.LENGTH_SHORT).show();
                return;
            }

            double salario = Double.parseDouble(salarioStr);
            double percentual = 0.0;

            int selectedId = groupAumento.getCheckedRadioButtonId();
            if (selectedId == R.id.percent40) percentual = 0.40;
            else if (selectedId == R.id.percent45) percentual = 0.45;
            else if (selectedId == R.id.percent50) percentual = 0.50;
            else {
                Toast.makeText(this, "Selecione um percentual de aumento!", Toast.LENGTH_SHORT).show();
                return;
            }

            double novoSalario = salario + (salario * percentual);
            String resultado = String.format("Novo salário: R$ %.2f", novoSalario);

            Animation fade = new AlphaAnimation(0, 1);
            fade.setDuration(400);
            textResultado.startAnimation(fade);
            textResultado.setText(resultado);
        });
    }
}